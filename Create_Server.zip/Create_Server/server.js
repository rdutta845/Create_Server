const http = require('http');
const fs = require('fs');
const htmlMap = {
    '/': './views/index.html',
    '/admin': './views/admin.html',
    '/favicon.ico': './views/error.html'

}

var server = http.createServer(function (req, res) {
    console.log("request", req.method);
    body = [];
    req.on("end", function () {
        body = Buffer.concat(body).toString();
        if (req.method === "POST") {
            res.writeHead(200, { 'content-Type': 'application/json' });
            res.write(body);
            res.end()
        }
        console.log("end request", body);

    })
    req.on("data", function (data) {
        body.push(data);
        console.log("body request", body);

    })

});


server.on('request', function (req, res) {
    const path = htmlMap[req.url] ? htmlMap[req.url] : './views/error.html';
    console.log("path", req.url);
    if (req.method === "POST") {
        return;
    }
    fs.readFile(path, function (err, html) {
        if (err) {
            console.log("error admin");
        }
        res.writeHead(200, { 'content-Type': 'text/html' })
        res.write(html);
        res.end();
    })
})


server.listen(5000); //3 - listen for any incoming requests

console.log('Node.js web server at port 5000 is running..')
